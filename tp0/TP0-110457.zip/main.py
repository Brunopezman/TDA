from collections import deque

cartas = "archivo.txt"

def apilar_cartas(cartas):
    cantidad_pilas = []

    with open(cartas, 'r') as f:
        for linea in f:
            carta = int(linea.strip())

            colocada = False
            for p in cantidad_pilas:
                if carta < p[0]:
                    p.appendleft(carta)
                    colocada = True
                    break
                
            if not colocada:
                nueva_pila = deque([carta])
                cantidad_pilas.append(nueva_pila)

    return print(len(cantidad_pilas))

apilar_cartas(cartas)